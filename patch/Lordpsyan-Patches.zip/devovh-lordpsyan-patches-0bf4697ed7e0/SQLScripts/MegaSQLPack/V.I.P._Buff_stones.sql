REPLACE INTO item_template (entry, name, displayid, Quality, Flags, Stackable, spellid_1, description) VALUES
 
 (700004, "V.I.P. Buff Stone - MELEE [10% all stats)", 120097, 7, 134217728, 1, 35874, "|cffffff00Right Click on the item to use. Account bound item."),

 (700005, "V.I.P. Buff Stone - RANGED [10% all stats)", 120097, 7, 134217728, 1, 38734, "|cffffff00Right Click on the item to use. Account bound item."),

 (700006, "V.I.P. Buff Stone - MAGIC [10% all stats)", 120097, 7, 134217728, 1, 35912, "|cffffff00Right Click on the item to use. Account bound item.");