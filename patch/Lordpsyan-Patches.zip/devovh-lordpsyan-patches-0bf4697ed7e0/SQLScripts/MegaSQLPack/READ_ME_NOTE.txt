---------------------------------------------------------------------------------------------------------------

About pack:

The project created for the purpose of easier gathering the SQL modifications for the game 
World of Warcraft Wrath of the Lich King.All you need, all you want, all you may ever think you'll need, and 
you're not able to do it, is here. Pack includes content with high quality of SQL scripting, which takea hours
to test it, to create it, to gather it and to make it publicly visible. And now here you are, just execute it 
all to your own server and enjoy ambitious project of FULLHOUSER'S SQL MEGA PACK.

Every single NPCs SQL file in this pack contains their own spawns ofc.

*I*M*P*O*R*T*A*N*T*
Execute all of SQL files respectively in order they are marked with numbers!
Do not try to do otherwise. It may doesn't work


SPECIAL THANKS TO
> MICAKILLERIC - for Heaven Stair event
> IKOKI - for custom boss Consur
> J-A-C-O-B - for profession vendors
> BESTSERVERLIST - for all in one trainer
> ROCHET2 - for Server Teleporter
> THE_ORIGINAL_BADOT - for Pocket Teleporter
> JEUTIE - for great core (repack) on which one I've tested all of my stuff
> ME for everything else included in this great SQL PACK

---------------------------------------------------------------------------------------------------------------

1. Server Teleporter
2. Pocket Teleporter
3. Profession Teleporter
4. Modified items
5. Global class + Weapons . Riding trainer
6. Profession Trainers
7. Gunship battlle custom boss
8. Custom event boss Consur
9. Daily quests NPC
10. Daily Quests
11. 200k Gold Bar
12. Guild House Token
13. Event Mark - item
14. Everywhere flying mount
15. Administrator Tabard + Shirt
16. Boost Tabard + Shirt
17. Raidhelper Equip
18. V.I.P. Buff stones
19. Emblem of Frost + Gold Bar Vendor
20. Guild House chain quest
21. Event Vendor
22. Furiozs + Relentness vendor
23. Arena organizers spawns - Orgrimmar and Stormwind
24. Class mats + Soul shards + Totems Vendor
25. Heirloom vendor
26. Profession Mats Vendors
27. Ulduar + Trial of Crusader + Icecrown Citadel plans vendor
28. Events - Stairs to Heaven, Medium Maze, Huge Maze, Easy jump, Hard Jump
29. Class Cloaks
30. Class cloaks quests
31. Welcome NPC + quest
32. NPC Buffer