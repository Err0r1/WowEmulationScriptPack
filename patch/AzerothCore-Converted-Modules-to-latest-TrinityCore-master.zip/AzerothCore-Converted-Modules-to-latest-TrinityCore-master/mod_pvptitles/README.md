# AzerothCore-Converted-Modules-to-latest-TrinityCore
AzerothCore Converted Modules to latest TrinityCore 3.3.5a WotLK

Please Note:
Better Version from TrinityCore Custom - Wiki use this Link below:
https://github.com/TrinityCore/TrinityCoreCustomChanges/wiki