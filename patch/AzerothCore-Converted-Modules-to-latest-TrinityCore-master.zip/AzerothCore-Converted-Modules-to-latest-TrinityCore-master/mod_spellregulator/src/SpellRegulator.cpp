#include "SpellRegulator.h"

void AddSC_SpellRegulator()
{
	new RegulatorLoader;
}