-- Warrior
INSERT INTO `playercreateinfo_spell_custom` (`race`, `classmask`, `Spell`, `Note`) VALUES
(0, 1, 33389, 'Apprentice Riding'),
(0, 1, 33392, 'Journeyman Riding'),
(0, 1, 34092, 'Expert Riding'),
(0, 1, 34093, 'Artisan Riding'),
(0, 1, 54198, 'Cold Weather Flying');
-- Paladin
INSERT INTO `playercreateinfo_spell_custom` (`race`, `classmask`, `Spell`, `Note`) VALUES
(0, 2, 33389, 'Apprentice Riding'),
(0, 2, 33392, 'Journeyman Riding'),
(0, 2, 34092, 'Expert Riding'),
(0, 2, 34093, 'Artisan Riding'),
(0, 2, 54198, 'Cold Weather Flying');
-- Hunter
INSERT INTO `playercreateinfo_spell_custom` (`race`, `classmask`, `Spell`, `Note`) VALUES
(0, 3, 33389, 'Apprentice Riding'),
(0, 3, 33392, 'Journeyman Riding'),
(0, 3, 34092, 'Expert Riding'),
(0, 3, 34093, 'Artisan Riding'),
(0, 3, 54198, 'Cold Weather Flying');
-- Rogue
INSERT INTO `playercreateinfo_spell_custom` (`race`, `classmask`, `Spell`, `Note`) VALUES
(0, 4, 33389, 'Apprentice Riding'),
(0, 4, 33392, 'Journeyman Riding'),
(0, 4, 34092, 'Expert Riding'),
(0, 4, 34093, 'Artisan Riding'),
(0, 4, 54198, 'Cold Weather Flying');
-- Priest
INSERT INTO `playercreateinfo_spell_custom` (`race`, `classmask`, `Spell`, `Note`) VALUES
(0, 5, 33389, 'Apprentice Riding'),
(0, 5, 33392, 'Journeyman Riding'),
(0, 5, 34092, 'Expert Riding'),
(0, 5, 34093, 'Artisan Riding'),
(0, 5, 54198, 'Cold Weather Flying');
-- Death Knight
INSERT INTO `playercreateinfo_spell_custom` (`race`, `classmask`, `Spell`, `Note`) VALUES
(0, 6, 33389, 'Apprentice Riding'),
(0, 6, 33392, 'Journeyman Riding'),
(0, 6, 34092, 'Expert Riding'),
(0, 6, 34093, 'Artisan Riding'),
(0, 6, 54198, 'Cold Weather Flying');
-- Shaman
INSERT INTO `playercreateinfo_spell_custom` (`race`, `classmask`, `Spell`, `Note`) VALUES
(0, 7, 33389, 'Apprentice Riding'),
(0, 7, 33392, 'Journeyman Riding'),
(0, 7, 34092, 'Expert Riding'),
(0, 7, 34093, 'Artisan Riding'),
(0, 7, 54198, 'Cold Weather Flying');
-- Mage
INSERT INTO `playercreateinfo_spell_custom` (`race`, `classmask`, `Spell`, `Note`) VALUES
(0, 8, 33389, 'Apprentice Riding'),
(0, 8, 33392, 'Journeyman Riding'),
(0, 8, 34092, 'Expert Riding'),
(0, 8, 34093, 'Artisan Riding'),
(0, 8, 54198, 'Cold Weather Flying');
-- Warlock
INSERT INTO `playercreateinfo_spell_custom` (`race`, `classmask`, `Spell`, `Note`) VALUES
(0, 9, 33389, 'Apprentice Riding'),
(0, 9, 33392, 'Journeyman Riding'),
(0, 9, 34092, 'Expert Riding'),
(0, 9, 34093, 'Artisan Riding'),
(0, 9, 54198, 'Cold Weather Flying');
-- Druid
INSERT INTO `playercreateinfo_spell_custom` (`race`, `classmask`, `Spell`, `Note`) VALUES
(0, 11, 33389, 'Apprentice Riding'),
(0, 11, 33392, 'Journeyman Riding'),
(0, 11, 34092, 'Expert Riding'),
(0, 11, 34093, 'Artisan Riding'),
(0, 11, 54198, 'Cold Weather Flying');