# AzerothCore-Converted-Modules-to-latest-TrinityCore
AzerothCore Converted Modules to latest TrinityCore 3.3.5a WotLK

Please Note:
Somehow this Module is incomplete, i can not make it working.

If you know what needs to be done to make it working, please contact me.

Skype: Masterbaron@msn.com
Discord: TheFrozenThr0ne 蛇#3075
