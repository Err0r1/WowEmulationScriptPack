# AzerothCore-Converted-Modules-to-latest-TrinityCore
AzerothCore Converted Modules to latest TrinityCore 3.3.5a WotLK and 9.0.5 Shadowlands

# Notice
If you are looking for some Patches by Trinitycore. Then check this link. https://github.com/TrinityCore/TrinityCoreCustomChanges/wiki

Information about applying Patches:
Patches are always better because you can revert them to apply new updates to your core. Use "git apply PatchFile.diff --rej" to apply patches. Use "git apply -R PatchFile.diff --rej" to revert them.