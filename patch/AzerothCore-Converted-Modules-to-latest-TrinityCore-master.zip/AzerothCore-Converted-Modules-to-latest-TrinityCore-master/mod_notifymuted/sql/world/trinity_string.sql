-- Language

INSERT INTO `trinity_string`(`entry`, `content_default`, `content_loc8`) VALUES
(13000, 'Player %s will not be able to speak yet: %s', '|cffff0000# |cff00ff00Игрок|r %s |cff00ff00не сможет говорить ещё: |cffff0000%s');