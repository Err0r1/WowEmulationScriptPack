# AzerothCore-Converted-Modules-to-latest-TrinityCore
AzerothCore Converted Modules to latest TrinityCore 9.0.5 Shadowlands
