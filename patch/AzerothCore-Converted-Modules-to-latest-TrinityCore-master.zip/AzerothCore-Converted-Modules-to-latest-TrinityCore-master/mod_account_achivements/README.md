# AzerothCore-Converted-Modules-to-latest-TrinityCore
AzerothCore Converted Modules to latest TrinityCore 3.3.5a WotLK
